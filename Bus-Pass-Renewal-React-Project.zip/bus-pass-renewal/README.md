# BusPass Student Portal (React)

## Start the project
1. Extract the ZIP file.
2. Open this folder in VS Code.
3. Open Terminal in this folder.
4. Run `npm install`.
5. Run `npm run dev`.
6. Open the localhost address printed in the terminal (usually http://localhost:5173).

## Build
Run `npm run build`.

## Included
- Student dashboard with sample bus pass
- New pass application form
- Pass renewal form
- Estimated fee by pass type
- Application history and status display
- Responsive mobile and desktop layout

## Demo limitation
This is a frontend demo. It does not connect to APSRTC or a government database, process real payments, authenticate users, or issue an official pass. Sample student/pass data is for demonstration only.
