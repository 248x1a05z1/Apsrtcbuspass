import { useState } from "react";

const initialApps = [
  { id: "APP-10482", type: "Monthly Student Pass", date: "01 Nov 2026", status: "Approved" },
  { id: "APP-09821", type: "Monthly Student Pass", date: "01 Oct 2026", status: "Approved" },
];

export default function App() {
  const [page, setPage] = useState("overview");
  const [apps, setApps] = useState(initialApps);
  const [message, setMessage] = useState("");
  const [form, setForm] = useState({ name: "Ravi Kumar", phone: "", email: "", college: "Government Polytechnic", studentId: "", from: "Guntur", to: "Vijayawada", type: "Monthly Student Pass" });
  const prices = { "Weekly Student Pass": 150, "Monthly Student Pass": 450, "Quarterly Student Pass": 1200 };
  const update = e => setForm({ ...form, [e.target.name]: e.target.value });
  const apply = e => {
    e.preventDefault();
    const id = "APP-" + Math.floor(10000 + Math.random() * 90000);
    setApps([{ id, type: form.type, date: new Date().toLocaleDateString("en-IN"), status: "Submitted" }, ...apps]);
    setMessage("Application submitted! Reference number: " + id);
    setPage("history");
  };
  const renew = () => { setForm({ ...form, name: "Ravi Kumar", college: "Government Polytechnic", from: "Guntur", to: "Vijayawada" }); setPage("renew"); setMessage(""); };
  const nav = [{id:"overview",label:"Overview",icon:"▦"},{id:"apply",label:"Apply for Pass",icon:"＋"},{id:"renew",label:"Renew Pass",icon:"↻"},{id:"history",label:"Application History",icon:"◷"}];
  return <div className="layout">
    <aside className="sidebar">
      <div className="brand"><div className="logo">B</div><div><b>BusPass</b><small>STUDENT PORTAL</small></div></div>
      <div className="profile"><div className="avatar">RK</div><div><b>Ravi Kumar</b><small>Student Account</small></div></div>
      <p className="caption">MENU</p>
      {nav.map(n=><button key={n.id} className={"nav "+(page===n.id?"active":"")} onClick={()=>{setPage(n.id);setMessage("");}}><span>{n.icon}</span>{n.label}</button>)}
      <div className="help"><b>ⓘ Need help?</b><p>Contact our support team for assistance with your pass.</p><a href="mailto:support@buspass.example">Contact support ↗</a></div>
      <small className="copyright">© 2026 BusPass Portal</small>
    </aside>
    <main className="main">
      <header><span className="mobile-brand">🚌 BusPass</span><div className="crumb">Student Portal　/　<strong>{page==="overview"?"Dashboard":page==="apply"?"Apply for a bus pass":page==="renew"?"Renew your bus pass":"Application history"}</strong></div><span className="online">● Portal online　　<span className="avatar tiny">RK</span></span></header>
      <section className="content">
        <div className="welcome"><div><small className="date">THURSDAY, 05 NOVEMBER 2026</small><h1>{page==="overview"?"Welcome back, Ravi! 👋":page==="apply"?"Apply for a bus pass":page==="renew"?"Renew your bus pass":"Application history"}</h1><p>{page==="overview"?"Manage your bus pass and track your applications in one place.":"Enter your details below to continue."}</p></div>{page==="overview"&&<button className="primary" onClick={()=>setPage("apply")}>＋ Apply for new pass</button>}</div>
        {message&&<div className="notice">✓　{message}<button onClick={()=>setMessage("")}>×</button></div>}
        {page==="overview"&&<>
          <div className="stats">
            <div className="stat"><i className="green">▣</i><small>Pass status</small><b>Active</b><em>Your pass is currently valid</em></div>
            <div className="stat"><i className="blue">◷</i><small>Valid until</small><b>30 Nov 2026</b><em>25 days remaining</em></div>
            <div className="stat"><i className="purple">⌁</i><small>Active route</small><b>Guntur – Vijayawada</b><em>Your registered route</em></div>
          </div>
          <div className="section-title"><div><h2>Your current bus pass</h2><p>Pass details and validity information</p></div><span className="badge approved">● Active</span></div>
          <div className="pass">
            <div className="pass-head"><div><small>STUDENT TRAVEL PASS</small><h2>Andhra Pradesh State Road Transport</h2><p>Student Concession Pass</p></div><div className="seal">APS<br/>RTC</div></div>
            <div className="pass-body"><div className="holder"><div className="photo">RK</div><div><small>PASS HOLDER</small><b>Ravi Kumar</b><p>Government Polytechnic</p></div></div><div className="details"><div><small>PASS ID</small><b>BP-2026-10482</b></div><div><small>TRAVEL ROUTE</small><b>Guntur ⇄ Vijayawada</b></div><div><small>PASS TYPE</small><b>Student Monthly</b></div><div><small>VALID UP TO</small><b>30 Nov 2026</b></div></div></div>
            <div className="pass-foot"><span>✦ Valid for authorized student travel only</span><button onClick={renew}>Renew this pass →</button></div>
          </div>
          <div className="section-title recent"><div><h2>Recent applications</h2><p>Check the latest updates on your requests</p></div><button className="link" onClick={()=>setPage("history")}>View all →</button></div>
          <Applications apps={apps.slice(0,3)}/>
          <p className="disclaimer">Demo portal: submissions are stored only in this browser session. No real payment or official pass is issued.</p>
        </>}
        {(page==="apply"||page==="renew")&&<form className="form-card" onSubmit={apply}>
          <div className="form-intro"><div className="form-symbol">{page==="renew"?"↻":"＋"}</div><div><h2>{page==="renew"?"Renew your existing pass":"Student bus pass application"}</h2><p>{page==="renew"?"Confirm your details and submit a renewal request.":"Enter your details to request a new student travel pass."}</p></div></div>
          <h3>Personal information</h3><div className="form-grid">
            <Field label="Full name *"><input name="name" value={form.name} onChange={update} required placeholder="Full name"/></Field>
            <Field label="Mobile number *"><input name="phone" value={form.phone} onChange={update} required maxLength="10" inputMode="numeric" placeholder="10-digit mobile number"/></Field>
            <Field label="Email address"><input name="email" type="email" value={form.email} onChange={update} placeholder="name@example.com"/></Field>
            <Field label="Institution / College *"><input name="college" value={form.college} onChange={update} required placeholder="College name"/></Field>
            <Field label="Student ID / Roll number"><input name="studentId" value={form.studentId} onChange={update} placeholder="Student ID"/></Field>
          </div>
          <h3>Travel information</h3><div className="form-grid">
            <Field label="From stop *"><input name="from" value={form.from} onChange={update} required/></Field>
            <Field label="To stop *"><input name="to" value={form.to} onChange={update} required/></Field>
            <Field label="Pass type"><select name="type" value={form.type} onChange={update}><option>Weekly Student Pass</option><option>Monthly Student Pass</option><option>Quarterly Student Pass</option></select></Field>
            <div className="fee"><span>Estimated pass fee<small>Subject to official verification</small></span><b>₹{prices[form.type]}</b></div>
          </div>
          <div className="actions"><button type="button" className="secondary" onClick={()=>setPage("overview")}>Cancel</button><button className="primary">Submit application →</button></div>
          <p className="fineprint">By submitting, you confirm that the information provided is accurate.</p>
        </form>}
        {page==="history"&&<><div className="section-title"><div><h2>All applications</h2><p>Track the status of your bus pass requests</p></div><button className="primary" onClick={()=>setPage("apply")}>＋ New application</button></div><Applications apps={apps}/></>}
      </section>
    </main>
  </div>;
}
function Field({label,children}){return <label className="field"><span>{label}</span>{children}</label>}
function Applications({apps}){return <div className="table-wrap"><table><thead><tr><th>REFERENCE ID</th><th>APPLICATION TYPE</th><th>SUBMITTED ON</th><th>STATUS</th></tr></thead><tbody>{apps.map(a=><tr key={a.id}><td className="ref">{a.id}</td><td>{a.type}</td><td>{a.date}</td><td><span className={"badge "+(a.status==="Approved"?"approved":"pending")}>{a.status==="Approved"?"●":"◷"} {a.status}</span></td></tr>)}</tbody></table>{!apps.length&&<p className="empty">No applications yet.</p>}</div>}
